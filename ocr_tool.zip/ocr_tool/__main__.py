from ocr_tool.ocr_tool import OcrTool


def main():
    chris_app = OcrTool()
    chris_app.launch()


if __name__ == "__main__":
    main()
